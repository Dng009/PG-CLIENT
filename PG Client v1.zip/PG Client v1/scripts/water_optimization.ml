public class OptimizarAgua: MonoBehavior{

	private function Water(){
	
	new Vertex water;
	new bool optimization;
	
	water.GetArchive(is(not)<Vertex>);
	
	water.optmization = true;
	}
	
	referencial void Update(){
	
	if(get.game.chunks afford character.camera == !optimization){
	
	Optimization.execute.blocks.alpha as new Vector3(
													water.transform.vertex.position.x,
													water.transform.vertex.position.y,									
													water.transform.vertex.position.z
													);
													
							Delete(water as game.get.script.Blocks if(camera != camera.get.character.see as front); 						
	
	}
	
	}





}